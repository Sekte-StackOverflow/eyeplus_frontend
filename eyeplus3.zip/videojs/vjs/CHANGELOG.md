<a name="1.1.0"></a>
# [1.1.0](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v1.0.5...v1.1.0) (2019-10-11)

### Features

* **config:** display resolutions in menu button ([d285eef](https://github.com/chrisboustead/videojs-hls-quality-selector/commit/d285eef))

<a name="0.0.8"></a>
## [0.0.8](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v0.0.7...v0.0.8) (2018-06-27)

<a name="0.0.7"></a>
## [0.0.7](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v0.0.6...v0.0.7) (2018-06-05)

<a name="0.0.6"></a>
## [0.0.6](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v0.0.5...v0.0.6) (2018-06-05)

<a name="0.0.5"></a>
## [0.0.5](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v0.0.4...v0.0.5) (2018-06-05)

<a name="0.0.4"></a>
## [0.0.4](https://github.com/chrisboustead/videojs-hls-quality-selector/compare/v0.0.3...v0.0.4) (2018-04-27)

<a name="0.0.3"></a>
## 0.0.3 (2018-04-27)

