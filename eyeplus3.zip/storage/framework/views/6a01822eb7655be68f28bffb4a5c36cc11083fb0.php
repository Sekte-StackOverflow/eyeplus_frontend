<?php $__env->startSection('heading'); ?>
  <img src="https://1.bp.blogspot.com/-RI22TMdzSJk/WgmxvNJMWAI/AAAAAAAAFwg/7DIp4G5wxR8BD0uEItY4UjF4oKB8QZZagCLcBGAs/s1600/Sosmed.jpg" class="img-rounded" style="width:100%" alt="Image">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="social text-center">
<?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a class="social-icon" data-tooltip="Youtube" href="<?php echo e($link->youtube); ?>" target="_blank">
    <img src="<?php echo e(URL::to('/image/youtube.png')); ?>" width="100%" height="100%">
  </a>
  <a class="social-icon" data-tooltip="Instagram" href="<?php echo e($link->instagram); ?>" target="_blank">
    <img src="<?php echo e(URL::to('/image/instagram.png')); ?>" width="100%" height="100%">
  </a>
  <a class="social-icon" data-tooltip="Facebook" href="<?php echo e($link->facebook); ?>" target="_blank">
    <img src="<?php echo e(URL::to('/image/facebook.png')); ?>" width="100%" height="100%">
  </a>
  <a class="social-icon" data-tooltip="Twitter" href="<?php echo e($link->twitter); ?>" target="_blank">
    <img src="<?php echo e(URL::to('/image/twitter.png')); ?>" width="100%" height="100%">
  </a>
  <a class="social-icon" data-tooltip="Pinterest" href="<?php echo e($link->pinterest); ?>" target="_blank">
    <img src="<?php echo e(URL::to('/image/pinterest.png')); ?>" width="100%" height="100%">
  </a>
  <a class="social-icon" data-tooltip="LinkedIn" href="<?php echo e($link->linkedin); ?>" target="_blank"s>
    <img src="<?php echo e(URL::to('/image/linkedin.png')); ?>" width="100%" height="100%">
  </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eyeplus\resources\views/sosmed.blade.php ENDPATH**/ ?>