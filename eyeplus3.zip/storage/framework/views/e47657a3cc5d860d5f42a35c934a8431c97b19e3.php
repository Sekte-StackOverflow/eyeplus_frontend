<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<p>Hi, <?php echo e($name); ?></p>
<p><?php echo e($email_body); ?></p>
<p><?php echo e($token); ?></p>
<p>url :<?php echo e($url); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\eyeplus\resources\views/email_template.blade.php ENDPATH**/ ?>