<?php $__env->startSection('heading'); ?>
  <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="embed-responsive embed-responsive-16by9">
      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($p->youtube); ?>" allowfullscreen></iframe>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<main>
    <section class="barang-cards">
      <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article>
          <img class="barang-img" src="https://alvaindopratama.com/admin-eyeplus/media/img/<?php echo e($p->thumnail); ?>" alt=" " />
          <font class="harga-asli1"><s> Rp. <?php echo number_format($p->price, 0, ',', '.'); ?> </s><font class="diskon1"><?php echo e($p->discount); ?> %</font></font>
          <font class="harga1">Rp. <?php echo number_format($p->finalprice, 0, ',', '.'); ?></font>
        </article>
        <article style="background-color: white">
          <img class="mini-img" src="https://alvaindopratama.com/admin-eyeplus/media/img/<?php echo e($p->detailgambar); ?>">
            <div style="margin: 5px"><b><?php echo e($p->nama); ?></b></div>
          	<div class="barang-ket" id="ex3">
          		<hr class="barang-hr">
          		<?php $__currentLoopData = $template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          		<div class="row">
      					  <div class="column">
      					    <?php echo e($t->deskripsi); ?>

      					  </div>
      					  <div class="column2">
      					    : <?php echo e($t->value); ?>

      					  </div>
					     </div>
					     <hr class="barang-hr">
				      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</div> 
        </article>
        <article>
          <img class="barang-img" src="<?php echo e(asset('image/banner/popup1.png')); ?>" alt=" " />
        </article>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
</main><br>
<?php $__env->stopSection(); ?>

<style type="text/css">
  .mini-img {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  margin-left: 5px;
}

.barang-ket{
  margin:5px; 
  padding:5px; 
  width: auto; 
  height: 210px; 
  overflow: auto; 
  text-align:justify;
  overflow-x: hidden;
  overflow-y: scroll;
}

#ex3::-webkit-scrollbar{
width:11px;
background-color:white;
} 
#ex3::-webkit-scrollbar-thumb{
background-color:#ebebeb;
border-radius:10px;
}
#ex3::-webkit-scrollbar-thumb:hover{
background-color:#c4c2c2;
border:2px solid #8c8b8b;
}
#ex3::-webkit-scrollbar-thumb:active{
background-color: #636363;
border:1px solid #333333;
} 

.harga1 {
  position: absolute;
  bottom: 36px;
  left: 150px;
  padding: 2px;
  color: white;
  font-weight:bold;
  font-size: 14px;
  background-color: #ff6f00;
}

.harga-asli1{
  position: absolute;
  bottom: 60px;
  left: 150px;
  padding: 0px 0px 0px 5px;
  color: white;
  font-weight:bold;
  font-size: 11px;
  background-color:#8a8884;
}

.diskon1{
  padding: 2px;
  color: white;
  font-weight:bold;
  font-size: 12px;
  padding: 1px 3px 1px 3px;
  background-color:#333333;
}
</style>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eyeplus\resources\views/barang.blade.php ENDPATH**/ ?>