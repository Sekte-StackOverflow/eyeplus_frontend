<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<p>Hi, {{ $name }}</p>
<p>{{ $email_body }}</p>
<p>{{ $token }}</p>
<p>url :{{ $url }}</p>
</body>
</html>